<?php
$fecha = getdate(mktime(18, 45, 0, 5, 1, 2010));
print_r($fecha);
?>
