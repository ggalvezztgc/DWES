<?php
$cadena = "Agencia de Seguridad Nacional para la Defensa";
echo strrev($cadena);
?>
