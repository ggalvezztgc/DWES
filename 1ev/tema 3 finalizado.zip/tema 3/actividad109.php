<?php
date_default_timezone_set('Europe/Madrid');

echo "a) " . date("F j, Y, g:i a") . "<br>";
echo "b) " . date("m.d.y") . "<br>";
echo "c) " . date("j, n, Y") . "<br>";
echo "d) " . date("Ymd") . "<br>";
echo "e) " . date("h-i-s, d-m-y") . "<br>";
echo "f) " . date("D M j H:i:s") . "<br>";
echo "g) " . date("H:i:s") . "<br>";
?>
