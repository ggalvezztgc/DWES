<?php
$texto1 = "esto es una prueba de texto";
$texto2 = "luis ros castro";

$texto1 = ucfirst($texto1);
$texto2 = ucwords($texto2);

echo $texto1 . "\n";
echo $texto2;
?>
