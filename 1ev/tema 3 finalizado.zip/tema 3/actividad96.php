<?php
$cadena = "3.500,00 €";
$cadenaRellena = str_pad($cadena, 20, "#", STR_PAD_BOTH);
echo $cadenaRellena;
?>
