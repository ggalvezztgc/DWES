<?php
$empleados = [
    ["nombre" => "Ana", "nota" => 8],
    ["nombre" => "Luis", "nota" => 6],
    ["nombre" => "Marta", "nota" => 9],
    ["nombre" => "Pedro", "nota" => 7],
    ["nombre" => "Lucía", "nota" => 10]
];

echo "Número de empleados: " . count($empleados);
?>
