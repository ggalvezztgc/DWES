<?php
for ($i = 200; $i <= 300; $i++) {
    echo $i . "<br>";
}

?>