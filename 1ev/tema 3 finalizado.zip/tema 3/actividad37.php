<?php
$contador = 320;
do {

    if($contador % 20 == 0)
    
    echo $contador . "<br>";
    
    $contador--;
    
} while ($contador>=160);
?>  