<?php
$sueldos = [1200, 1500, 900, 2000, 1700];
echo "El sueldo máximo es: " . max($sueldos) . "\n";
?>
