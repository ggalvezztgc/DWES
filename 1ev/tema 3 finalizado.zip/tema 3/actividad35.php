<?php

for($contador = 320; $contador>=160; $contador--){
    if($contador % 20 === 0)
echo $contador."<br>";
}

?>