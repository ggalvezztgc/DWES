<?php
$cadena1 = "Agencia de Seguridad Nacional para la Defensa";
$cadena2 = "Agencia de Seguridad Nacional";

if ($cadena1 === $cadena2) {
    echo "Las cadenas son iguales.";
} else {
    echo "Las cadenas son diferentes.";
}
?>
