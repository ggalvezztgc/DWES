<?php

$numero = 54321;
$numero = abs($numero);
$digitos = strlen("$numero");
echo "El número $numero tiene $digitos dígitos";

?>
