<?php
$cadena = "Agencia de Seguridad Nacional para la Defensa";
$cadena = str_replace("Seguridad", "Tramitación", $cadena);
echo $cadena;
?>

