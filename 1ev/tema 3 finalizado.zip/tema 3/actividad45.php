<?php
$numero = 5;
$sumatorio = 0;
for ($i = 1; $i <= $numero; $i++) {
    $sumatorio += $i;
}
echo "El sumatorio de $numero es $sumatorio";
?>
