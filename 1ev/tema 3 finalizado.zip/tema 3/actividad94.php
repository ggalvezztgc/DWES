<?php
$nombre = "Pedro Ros Molina";
$palabras = str_word_count($nombre);
echo "El nombre contiene " . $palabras . " palabras.";
?>
