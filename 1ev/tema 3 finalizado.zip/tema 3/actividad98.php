<?php
$cadena = "Pedro–Luis-Ana-Rosa-Angel";
$array = explode("-", $cadena);

print_r($array);
?>
