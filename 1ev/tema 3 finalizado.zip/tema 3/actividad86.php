<?php
function mayorDeTres($a, $b, $c) {
    return max($a, $b, $c);
}

echo "El mayor es: " . mayorDeTres(15, 42, 27);
?>
