<?php
$n = 100; 
for ($i = 1; $i <= $n; $i += 7) {
    echo $i . "<br>";
}
?>
