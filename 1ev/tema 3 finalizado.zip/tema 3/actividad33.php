<?php
    $contador =1; 
    while ($contador <= 100){
        if($contador % 5 == 0){
        echo $contador . "<br>";
        
        }
        $contador++;
    }
?>

    
