<?php
$dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
$cadena = implode(":", $dias);
echo $cadena;
?>
