<?php
$numeros = [3, 7, 9, 10, 12];
foreach ($numeros as $num) if ($num % 3 == 0) echo "$num es múltiplo de 3\n";
?>
