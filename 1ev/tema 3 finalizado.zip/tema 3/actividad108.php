<?php
echo "Segundos transcurridos desde el 1 de Enero de 1970 hasta hoy: " . time();
?>
