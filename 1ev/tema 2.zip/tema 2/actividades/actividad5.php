<?php
$texto = "Hola mundo";
$entero = 42;
$decimal = 3.14;

echo "La variable texto es de tipo: " . gettype($texto) . "<br>";
echo "La variable entero es de tipo: " . gettype($entero) . "<br>";
echo "La variable decimal es de tipo: " . gettype($decimal) . "<br>";
?>
