<?php
$texto = "Hola, mundo";
$entero = 42;
$decimal = 3.14;

echo "Variable de texto: " . $texto . "<br>";
echo "Variable entera: " . $entero . "<br>";
echo "Variable decimal: " . $decimal . "<br>";
?>
