<?php
echo "Versión de PHP: " . phpversion() . "<br>";

echo "Sistema operativo: " . PHP_OS;
?>
