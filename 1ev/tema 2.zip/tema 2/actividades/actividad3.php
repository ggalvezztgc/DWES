<?php
$dias = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");

foreach ($dias as $dia) {
    echo $dia . "<br>";
}
?>
