<?php
$hora = 14;
if ($hora >= 6 && $hora <= 12) echo "Buenos días\n";
elseif ($hora >= 13 && $hora <= 20) echo "Buenas tardes\n";
else echo "Buenas noches\n";
?>
