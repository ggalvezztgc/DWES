<?php
$contador = 1;
do {

    if($contador % 5 == 0)

    echo $contador . "<br>";
    
    $contador++;
    
} while ($contador<=100);
?>