<?php
    $contador =320; 
    while ($contador >= 160){
        if($contador % 20 == 0){
        echo $contador . "<br>";
        
        }
        $contador--;
    }
?>

    