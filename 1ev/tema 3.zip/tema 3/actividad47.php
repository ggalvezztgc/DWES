<?php
$hoteles = [
    [
        "Nombre" => "Meliá",
        "Cat" => "3*",
        "Hab" => 168,
        "Población" => "46100 Valencia",
        "Dirección" => "Empalme, 5"
    ],
    [
        "Nombre" => "Abba Acteon (Abba Hoteles)",
        "Cat" => "4*",
        "Hab" => 189,
        "Población" => "46023 Valencia",
        "Dirección" => "Escultor Vicente Bertrán Grimal, 2"
    ],
    [
        "Nombre" => "Acta del Carmen",
        "Cat" => "3*",
        "Hab" => 25,
        "Población" => "46003 Valencia",
        "Dirección" => "Blanqueries, 11"
       
    ],
    [
        "Nombre" => "Acta Atarazanas",
        "Cat" => "4*",
        "Hab" => 42,
        "Población" => "46011 Valencia",
        "Dirección" => "Plaza Tribunal de las Aguas, 4"
    ],
    [
        "Nombre" => "Alkazar",
        "Cat" => "1*",
        "Hab" => 18,
        "Población" => "46002 Valencia",
        "Dirección" => "Mosén Femades, 11"
        
    ],
    [
        "Nombre" => "Ad Hoc Monumental Valencia",
        "Cat" => "3*",
        "Hab" => 28,
        "Población" => "46003 Valencia",
        "Dirección" => "Boix, 4"
    ],
    [
        "Nombre" => "AC Valencia (AC Hotels)",
        "Cat" => "4*",
        "Hab" => 183,
        "Población" => "46023 Valencia",
        "Dirección" => "Avenida de Francia, 67"
    ]
];
?>
 