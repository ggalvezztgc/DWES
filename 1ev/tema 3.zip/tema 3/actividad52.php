<?php
$hoteles = [];
echo "Array de hoteles borrado.<br>";
var_dump($hoteles);
?>