<h2>CONCESIONARIO</h2>

<a href="alta.php">Alta de coche</a><br>
<a href="baja.php">Baja de coche</a><br>
<a href="consulta.php">Consulta de coche</a><br>
<a href="actualizacion.php">Actualizacion de coche</a><br>
<a href="listado.php">Listado de coches</a><br>
