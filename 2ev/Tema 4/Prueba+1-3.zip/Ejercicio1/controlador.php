<?php
    include "modelo.php";

    $alumnos = getAlumnos();
    
    include "vista.php";
?>