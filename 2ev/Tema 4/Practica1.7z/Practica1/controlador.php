<?php
include("modelo.php"); 
include("vista.php");  
?>
