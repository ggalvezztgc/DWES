<?php

$inmuebles = array(
    array("codigo"=>"V-101", "tipo"=>"Vivienda", "direccion"=>"C/ Mayor 12", "poblacion"=>"Valencia",
        "metros"=>85, "habitaciones"=>3, "banos"=>2, "garaje"=>1, "precio"=>160000,
        "altura"=>"3º", "balcon"=>"S", "exterior"=>"S", "foto"=>"chalet1.jpg"
    ),

    array("codigo"=>"V-102", "tipo"=>"Vivienda", "direccion"=>"Av. Mar 7", "poblacion"=>"Gandía",
        "metros"=>60, "habitaciones"=>2, "banos"=>1, "garaje"=>0, "precio"=>110000,
        "altura"=>"1º", "balcon"=>"N", "exterior"=>"S", "foto"=>"chalet2.jpg"
    ),

    array("codigo"=>"C-201", "tipo"=>"Chalet", "direccion"=>"Urb. Pinos 4", "poblacion"=>"Bétera",
        "metros"=>140, "habitaciones"=>4, "banos"=>2, "garaje"=>2, "precio"=>320000,
        "parcela"=>500, "piscina"=>"S", "paellero"=>"N", "foto"=>"chalet3.jpg"
    ),

    array("codigo"=>"C-202", "tipo"=>"Chalet", "direccion"=>"C/ Monte 9", "poblacion"=>"Chiva",
        "metros"=>120, "habitaciones"=>3, "banos"=>2, "garaje"=>1, "precio"=>250000,
        "parcela"=>350, "piscina"=>"S", "paellero"=>"S", "foto"=>"chalet4.jpg"
    )
);

?>
