<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>CURSO</title></head>
<body>
<h2>Acceso al curso</h2>
<form method="POST" action="CONTROL.PHP">
    Usuario: <input type="text" name="usuario"><br>
    Contraseña: <input type="password" name="pass"><br>
    <input type="submit" value="Entrar">
</form>
</body>
</html>
