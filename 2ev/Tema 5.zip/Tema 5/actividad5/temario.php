<?php
require_once "SEGURIDAD.PHP";
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>TEMARIO</title></head>
<body>
<h2>Zona segura - Temario del curso</h2>
<ul>
    <li><a href="tema1.pdf">Tema 1</a></li>
    <li><a href="tema2.pdf">Tema 2</a></li>
    <li><a href="tema3.pdf">Tema 3</a></li>
</ul>
<a href="DESCONECTAR.PHP">Salir</a>
</body>
</html>
