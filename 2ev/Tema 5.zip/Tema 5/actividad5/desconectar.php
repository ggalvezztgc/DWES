<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>DESCONECTAR</title></head>
<body>
<p>Sesión cerrada correctamente.</p>
<a href="CURSO.PHP">Volver a entrar</a>
</body>
</html>
